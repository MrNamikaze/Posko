<?php
// Initialize a cURL session
require_once("koneksi.php");
$ch = curl_init();

// Set the URL for the FHIR server endpoint
$url = "https://r4.smarthealthit.org/Patient";

// Set the options for the cURL session
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/fhir+json"
]);

// Execute the cURL session and get the response
$response = curl_exec($ch);

// Check for cURL errors
if ($response === false) {
    echo 'cURL Error: ' . curl_error($ch);
} else {
    // Decode the JSON response to a PHP array
    $data = json_decode($response, true);

    // Check if data was decoded successfully
    if (json_last_error() === JSON_ERROR_NONE) {
        // Print the fetched data
        for($a = 0; $a < 50; $a++){
            if($data['entry'][$a]['response']['status']=='200 OK'){
                $id_patient = $data['entry'][$a]['resource']['id'];
                $birthDate_patient = $data['entry'][$a]['resource']['birthDate'];
                $gender_patient = $data['entry'][$a]['resource']['gender'];
                $given_patient = $data['entry'][$a]['resource']['name'][0]['given'];
                $family_patient = $data['entry'][$a]['resource']['name'][0]['family'];
                $line_patient = $data['entry'][$a]['resource']['address'][0]['line'][0];
                $city_patient = $data['entry'][$a]['resource']['address'][0]['city'];
                $country_patient = $data['entry'][$a]['resource']['address'][0]['country'];
                $postalCode_patient = $data['entry'][$a]['resource']['address'][0]['postalCode'];
                $state_patient = $data['entry'][$a]['resource']['address'][0]['state'];
                $lastUpdated_patient = $data['entry'][$a]['resource']['meta']['lastUpdated'];
                $phone_patient = $data['entry'][$a]['resource']['telecom'][0]['value'];
                $latitude_patient = $data['entry'][$a]['resource']['address'][0]['extension'][0]['extension'][0]['valueDecimal'];
                $longitude_patient = $data['entry'][$a]['resource']['address'][0]['extension'][0]['extension'][1]['valueDecimal'];

                $sql1 = "SELECT * FROM patient WHERE id_patient = '$id_patient'";
                $row1 = $db->prepare($sql1);
                $row1->execute();
                $hasil1 = $row1->fetchAll();
                if(!empty($hasil1)){
                    echo 'a';
                }
                else{
                    $sql = "INSERT INTO patient (id_patient, birthDate_patient, gender_patient, given_patient, family_patient, line_patient, city_patient, country_patient, postalCode_patient, state_patient, lastUpdated_patient, phone_patient, latitude_patient, longitude_patient) 
                        VALUES (:id_patient, :birthDate_patient, :gender_patient, :given_patient, :family_patient, :line_patient, :city_patient, :country_patient, :postalCode_patient, :state_patient, :lastUpdated_patient, :phone_patient, :latitude_patient, :longitude_patient)";
                    $stmt = $db->prepare($sql);

                    // bind parameter ke query
                    $params = array(
                        ":id_patient" => $id_patient,
                        ":birthDate_patient" => $birthDate_patient,
                        ":gender_patient" => $gender_patient,
                        ":given_patient" => $given_patient,
                        ":family_patient" => $family_patient,
                        ":line_patient" => $line_patient,
                        ":city_patient" => $city_patient,
                        ":country_patient" => $country_patient,
                        ":postalCode_patient" => $postalCode_patient,
                        ":state_patient" => $state_patient,
                        ":lastUpdated_patient" => $lastUpdated_patient,
                        ":phone_patient" => $phone_patient,
                        ":latitude_patient" => $latitude_patient,
                        ":longitude_patient" => $longitude_patient,
                    );
                    // eksekusi query untuk menyimpan ke database
                    $saved = $stmt->execute($params);
                    if($saved){
                        echo 'b';
                    }
                    else{
                        echo 'c';
                    }
                }
            }
            else{
                echo 'error from server';
            }
        }
    } else {
        echo 'JSON Decode Error: ' . json_last_error_msg();
    }
}

// Close the cURL session
curl_close($ch);
?>
